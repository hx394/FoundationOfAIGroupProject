from .AutoROM import cli, main
